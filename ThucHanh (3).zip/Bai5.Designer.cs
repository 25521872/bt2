﻿namespace THUCHANH
{
    partial class Bai5
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            cboFilm = new ComboBox();
            cboRoom = new ComboBox();
            lblFilm = new Label();
            lblRoom = new Label();
            pnlSeats = new Panel();
            lblTotal = new Label();
            txtTotal = new TextBox();
            btnBuy = new Button();
            btnReport = new Button();
            rtbReport = new RichTextBox();
            lblTitle = new Label();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
            lblTitle.ForeColor = Color.DarkBlue;
            lblTitle.Location = new Point(200, 15);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(320, 32);
            lblTitle.Text = "HỆ THỐNG BÁN VÉ RẠP CHIẾU PHIM";
            // 
            // cboFilm
            // 
            cboFilm.DropDownStyle = ComboBoxStyle.DropDownList;
            cboFilm.FormattingEnabled = true;
            cboFilm.Location = new Point(110, 65);
            cboFilm.Name = "cboFilm";
            cboFilm.Size = new Size(200, 28);
            cboFilm.SelectedIndexChanged += cboFilm_SelectedIndexChanged;
            // 
            // cboRoom
            // 
            cboRoom.DropDownStyle = ComboBoxStyle.DropDownList;
            cboRoom.FormattingEnabled = true;
            cboRoom.Location = new Point(430, 65);
            cboRoom.Name = "cboRoom";
            cboRoom.Size = new Size(150, 28);
            cboRoom.SelectedIndexChanged += cboRoom_SelectedIndexChanged;
            // 
            // lblFilm
            // 
            lblFilm.AutoSize = true;
            lblFilm.Location = new Point(30, 68);
            lblFilm.Text = "Chọn phim:";
            // 
            // lblRoom
            // 
            lblRoom.AutoSize = true;
            lblRoom.Location = new Point(340, 68);
            lblRoom.Text = "Chọn phòng:";
            // 
            // pnlSeats
            // 
            pnlSeats.BorderStyle = BorderStyle.FixedSingle;
            pnlSeats.Location = new Point(30, 115);
            pnlSeats.Name = "pnlSeats";
            pnlSeats.Size = new Size(350, 230);
            // 
            // lblTotal
            // 
            lblTotal.AutoSize = true;
            lblTotal.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            lblTotal.Location = new Point(30, 365);
            lblTotal.Text = "Số tiền phải trả:";
            // 
            // txtTotal
            // 
            txtTotal.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            txtTotal.Location = new Point(160, 362);
            txtTotal.Name = "txtTotal";
            txtTotal.ReadOnly = true;
            txtTotal.Size = new Size(220, 30);
            // 
            // btnBuy
            // 
            btnBuy.BackColor = Color.LightGreen;
            btnBuy.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnBuy.Location = new Point(30, 410);
            btnBuy.Name = "btnBuy";
            btnBuy.Size = new Size(160, 40);
            btnBuy.Text = "MUA VÉ";
            btnBuy.UseVisualStyleBackColor = false;
            btnBuy.Click += btnBuy_Click;
            // 
            // btnReport
            // 
            btnReport.BackColor = Color.LightSkyBlue;
            btnReport.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            btnReport.Location = new Point(220, 410);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(160, 40);
            btnReport.Text = "XUẤT BÁO CÁO";
            btnReport.UseVisualStyleBackColor = false;
            btnReport.Click += btnReport_Click;
            // 
            // rtbReport
            // 
            rtbReport.Location = new Point(410, 115);
            rtbReport.Name = "rtbReport";
            rtbReport.Size = new Size(310, 335);
            rtbReport.Text = "";
            // 
            // Bai5
            // 
            ClientSize = new Size(750, 475);
            Controls.Add(lblTitle);
            Controls.Add(rtbReport);
            Controls.Add(btnReport);
            Controls.Add(btnBuy);
            Controls.Add(txtTotal);
            Controls.Add(lblTotal);
            Controls.Add(pnlSeats);
            Controls.Add(lblRoom);
            Controls.Add(lblFilm);
            Controls.Add(cboRoom);
            Controls.Add(cboFilm);
            Name = "Bai5";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bài 5 - Quản lý Đặt vé Rạp chiếu phim";
            Load += Bai5_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox cboFilm;
        private ComboBox cboRoom;
        private Label lblFilm;
        private Label lblRoom;
        private Panel pnlSeats;
        private Label lblTotal;
        private TextBox txtTotal;
        private Button btnBuy;
        private Button btnReport;
        private RichTextBox rtbReport;
        private Label lblTitle;
    }
}