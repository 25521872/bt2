﻿using System;
using System.Data;
using System.IO;
using System.Windows.Forms;

namespace THUCHANH
{
    public partial class Bai3 : Form
    {
        public Bai3()
        {
            InitializeComponent();
        }

        // 1. Nút ĐỌC FILE VÀ TÍNH TOÁN
        private void btnRead_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            ofd.Title = "Chọn file input3.txt";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    rtbContent.Clear(); // Xóa nội dung cũ trên khung hiển thị

                    string[] lines = File.ReadAllLines(ofd.FileName);

                    foreach (string line in lines)
                    {
                        if (string.IsNullOrWhiteSpace(line)) continue;

                        // Tính toán kết quả cho từng dòng biểu thức
                        string resultLine = CalculateExpression(line.Trim());
                        rtbContent.AppendText(resultLine + "\n");
                    }

                    MessageBox.Show("Đã đọc và tính toán xong!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi xử lý file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // 2. Nút GHI FILE KẾT QUẢ
        private void btnWrite_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            sfd.FileName = "output3.txt";
            sfd.Title = "Lưu kết quả phép tính";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write))
                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        sw.Write(rtbContent.Text);
                    }

                    MessageBox.Show("Đã ghi file kết quả thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi ghi file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Hàm hỗ trợ tính toán biểu thức đơn giản
        private string CalculateExpression(string expression)
        {
            try
            {
                // Dùng DataTable.Compute để tính toán biểu thức chuỗi một cách tiện lợi
                DataTable dt = new DataTable();
                var result = dt.Compute(expression, "");

                return $"{expression} = {result}";
            }
            catch
            {
                return $"{expression} = Lỗi biểu thức";
            }
        }
    }
}
