﻿namespace THUCHANH
{
    partial class Bai4
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            txtMSSV = new TextBox();
            txtName = new TextBox();
            txtPhone = new TextBox();
            txtCourse1 = new TextBox();
            txtCourse2 = new TextBox();
            txtCourse3 = new TextBox();
            txtAverage = new TextBox();
            lblMSSV = new Label();
            lblName = new Label();
            lblPhone = new Label();
            lblCourse1 = new Label();
            lblCourse2 = new Label();
            lblCourse3 = new Label();
            lblAverage = new Label();
            btnWriteToFile = new Button();
            btnReadFromFile = new Button();
            btnBack = new Button();
            btnNext = new Button();
            lblPage = new Label();
            rtbContent = new RichTextBox();
            btnAddStudent = new Button();
            SuspendLayout();
            // 
            // txtMSSV
            // 
            txtMSSV.Location = new Point(110, 30);
            txtMSSV.Name = "txtMSSV";
            txtMSSV.Size = new Size(180, 27);
            txtMSSV.TabIndex = 20;
            // 
            // txtName
            // 
            txtName.Location = new Point(110, 70);
            txtName.Name = "txtName";
            txtName.Size = new Size(180, 27);
            txtName.TabIndex = 19;
            // 
            // txtPhone
            // 
            txtPhone.Location = new Point(110, 110);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(180, 27);
            txtPhone.TabIndex = 18;
            // 
            // txtCourse1
            // 
            txtCourse1.Location = new Point(110, 150);
            txtCourse1.Name = "txtCourse1";
            txtCourse1.Size = new Size(180, 27);
            txtCourse1.TabIndex = 17;
            // 
            // txtCourse2
            // 
            txtCourse2.Location = new Point(110, 190);
            txtCourse2.Name = "txtCourse2";
            txtCourse2.Size = new Size(180, 27);
            txtCourse2.TabIndex = 16;
            // 
            // txtCourse3
            // 
            txtCourse3.Location = new Point(110, 230);
            txtCourse3.Name = "txtCourse3";
            txtCourse3.Size = new Size(180, 27);
            txtCourse3.TabIndex = 15;
            // 
            // txtAverage
            // 
            txtAverage.Location = new Point(110, 270);
            txtAverage.Name = "txtAverage";
            txtAverage.ReadOnly = true;
            txtAverage.Size = new Size(180, 27);
            txtAverage.TabIndex = 14;
            // 
            // lblMSSV
            // 
            lblMSSV.AutoSize = true;
            lblMSSV.Location = new Point(20, 33);
            lblMSSV.Name = "lblMSSV";
            lblMSSV.Size = new Size(50, 20);
            lblMSSV.TabIndex = 13;
            lblMSSV.Text = "MSSV:";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(20, 73);
            lblName.Name = "lblName";
            lblName.Size = new Size(57, 20);
            lblName.TabIndex = 12;
            lblName.Text = "Họ tên:";
            // 
            // lblPhone
            // 
            lblPhone.AutoSize = true;
            lblPhone.Location = new Point(20, 113);
            lblPhone.Name = "lblPhone";
            lblPhone.Size = new Size(39, 20);
            lblPhone.TabIndex = 11;
            lblPhone.Text = "SĐT:";
            // 
            // lblCourse1
            // 
            lblCourse1.AutoSize = true;
            lblCourse1.Location = new Point(20, 153);
            lblCourse1.Name = "lblCourse1";
            lblCourse1.Size = new Size(54, 20);
            lblCourse1.TabIndex = 10;
            lblCourse1.Text = "Môn 1:";
            // 
            // lblCourse2
            // 
            lblCourse2.AutoSize = true;
            lblCourse2.Location = new Point(20, 193);
            lblCourse2.Name = "lblCourse2";
            lblCourse2.Size = new Size(54, 20);
            lblCourse2.TabIndex = 9;
            lblCourse2.Text = "Môn 2:";
            // 
            // lblCourse3
            // 
            lblCourse3.AutoSize = true;
            lblCourse3.Location = new Point(20, 233);
            lblCourse3.Name = "lblCourse3";
            lblCourse3.Size = new Size(54, 20);
            lblCourse3.TabIndex = 8;
            lblCourse3.Text = "Môn 3:";
            // 
            // lblAverage
            // 
            lblAverage.AutoSize = true;
            lblAverage.Location = new Point(20, 273);
            lblAverage.Name = "lblAverage";
            lblAverage.Size = new Size(69, 20);
            lblAverage.TabIndex = 7;
            lblAverage.Text = "Điểm TB:";
            // 
            // btnWriteToFile
            // 
            btnWriteToFile.Location = new Point(20, 365);
            btnWriteToFile.Name = "btnWriteToFile";
            btnWriteToFile.Size = new Size(130, 40);
            btnWriteToFile.TabIndex = 6;
            btnWriteToFile.Text = "GHI VÀO FILE";
            btnWriteToFile.Click += btnWriteToFile_Click;
            // 
            // btnReadFromFile
            // 
            btnReadFromFile.Location = new Point(160, 365);
            btnReadFromFile.Name = "btnReadFromFile";
            btnReadFromFile.Size = new Size(130, 40);
            btnReadFromFile.TabIndex = 5;
            btnReadFromFile.Text = "ĐỌC TỪ FILE";
            btnReadFromFile.Click += btnReadFromFile_Click;
            // 
            // btnBack
            // 
            btnBack.Location = new Point(320, 365);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(80, 40);
            btnBack.TabIndex = 4;
            btnBack.Text = "Back";
            btnBack.Click += btnBack_Click;
            // 
            // btnNext
            // 
            btnNext.Location = new Point(480, 365);
            btnNext.Name = "btnNext";
            btnNext.Size = new Size(80, 40);
            btnNext.TabIndex = 3;
            btnNext.Text = "Next";
            btnNext.Click += btnNext_Click;
            // 
            // lblPage
            // 
            lblPage.AutoSize = true;
            lblPage.Location = new Point(420, 375);
            lblPage.Name = "lblPage";
            lblPage.Size = new Size(39, 20);
            lblPage.TabIndex = 2;
            lblPage.Text = "0 / 0";
            // 
            // rtbContent
            // 
            rtbContent.Location = new Point(320, 30);
            rtbContent.Name = "rtbContent";
            rtbContent.Size = new Size(400, 325);
            rtbContent.TabIndex = 1;
            rtbContent.Text = "";
            // 
            // btnAddStudent
            // 
            btnAddStudent.Location = new Point(20, 320);
            btnAddStudent.Name = "btnAddStudent";
            btnAddStudent.Size = new Size(270, 35);
            btnAddStudent.TabIndex = 0;
            btnAddStudent.Text = "THÊM SINH VIÊN VÀO DANH SÁCH";
            btnAddStudent.Click += btnAddStudent_Click;
            // 
            // Bai4
            // 
            ClientSize = new Size(745, 425);
            Controls.Add(btnAddStudent);
            Controls.Add(rtbContent);
            Controls.Add(lblPage);
            Controls.Add(btnNext);
            Controls.Add(btnBack);
            Controls.Add(btnReadFromFile);
            Controls.Add(btnWriteToFile);
            Controls.Add(lblAverage);
            Controls.Add(lblCourse3);
            Controls.Add(lblCourse2);
            Controls.Add(lblCourse1);
            Controls.Add(lblPhone);
            Controls.Add(lblName);
            Controls.Add(lblMSSV);
            Controls.Add(txtAverage);
            Controls.Add(txtCourse3);
            Controls.Add(txtCourse2);
            Controls.Add(txtCourse1);
            Controls.Add(txtPhone);
            Controls.Add(txtName);
            Controls.Add(txtMSSV);
            Name = "Bai4";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bài 4 - Quản lý Sinh viên (Ghi và Đọc File Binary)";
            ResumeLayout(false);
            PerformLayout();
        }

        private void BtnAddStudent_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void BtnWriteToFile_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void BtnReadFromFile_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void BtnNext_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        #endregion

        private TextBox txtMSSV;
        private TextBox txtName;
        private TextBox txtPhone;
        private TextBox txtCourse1;
        private TextBox txtCourse2;
        private TextBox txtCourse3;
        private TextBox txtAverage;
        private Label lblMSSV;
        private Label lblName;
        private Label lblPhone;
        private Label lblCourse1;
        private Label lblCourse2;
        private Label lblCourse3;
        private Label lblAverage;
        private Button btnAddStudent;
        private Button btnWriteToFile;
        private Button btnReadFromFile;
        private Button btnBack;
        private Button btnNext;
        private Label lblPage;
        private RichTextBox rtbContent;
    }
}