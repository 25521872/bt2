﻿namespace THUCHANH
{
    partial class Bai3
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            btnRead = new Button();
            btnWrite = new Button();
            rtbContent = new RichTextBox();
            SuspendLayout();
            // 
            // btnRead
            // 
            btnRead.Location = new Point(30, 30);
            btnRead.Name = "btnRead";
            btnRead.Size = new Size(160, 45);
            btnRead.TabIndex = 0;
            btnRead.Text = "ĐỌC & TÍNH TOÁN";
            btnRead.UseVisualStyleBackColor = true;
            btnRead.Click += btnRead_Click;
            // 
            // btnWrite
            // 
            btnWrite.Location = new Point(210, 30);
            btnWrite.Name = "btnWrite";
            btnWrite.Size = new Size(160, 45);
            btnWrite.TabIndex = 1;
            btnWrite.Text = "GHI FILE KẾT QUẢ";
            btnWrite.UseVisualStyleBackColor = true;
            btnWrite.Click += btnWrite_Click;
            // 
            // rtbContent
            // 
            rtbContent.Location = new Point(30, 95);
            rtbContent.Name = "rtbContent";
            rtbContent.Size = new Size(480, 280);
            rtbContent.TabIndex = 2;
            rtbContent.Text = "";
            // 
            // Bai3
            // 
            ClientSize = new Size(540, 400);
            Controls.Add(rtbContent);
            Controls.Add(btnWrite);
            Controls.Add(btnRead);
            Name = "Bai3";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Bài 3 - Tính toán Biểu thức từ File";
            ResumeLayout(false);
        }

        #endregion

        private Button btnRead;
        private Button btnWrite;
        private RichTextBox rtbContent;
    }
}