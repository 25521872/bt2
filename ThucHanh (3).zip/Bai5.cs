﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace THUCHANH
{
    public partial class Bai5 : Form
    {
        class Movie
        {
            public string Name { get; set; }
            public double BasePrice { get; set; }
            public List<int> Rooms { get; set; }
        }

        private List<Movie> movieList = new List<Movie>();
        // Trạng thái ghế: Key = "FilmName_Room_SeatName", Value = true (Đã bán) / false (Đang chọn)
        private Dictionary<string, bool> seatStatus = new Dictionary<string, bool>();
        private List<Button> selectedSeatButtons = new List<Button>();

        public Bai5()
        {
            InitializeComponent();
        }

        private void Bai5_Load(object sender, EventArgs e)
        {
            // Khoi tao danh sach Phim va Phong chieu
            movieList = new List<Movie>
            {
                new Movie { Name = "Đào, Phở và Piano", BasePrice = 45000, Rooms = new List<int> { 1, 2, 3 } },
                new Movie { Name = "Mai", BasePrice = 100000, Rooms = new List<int> { 2, 3 } },
                new Movie { Name = "Gặp Lại Chị Bầu", BasePrice = 70000, Rooms = new List<int> { 1 } }
            };

            cboFilm.DataSource = movieList.Select(m => m.Name).ToList();
            GenerateSeatGrid();
        }

        private void cboFilm_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedMovie = movieList.FirstOrDefault(m => m.Name == cboFilm.SelectedItem.ToString());
            if (selectedMovie != null)
            {
                cboRoom.DataSource = selectedMovie.Rooms;
            }
            ResetSeatSelection();
        }

        private void cboRoom_SelectedIndexChanged(object sender, EventArgs e)
        {
            ResetSeatSelection();
        }

        // Tạo sơ đồ ghế 3 hàng x 5 cột (A1-A5, B1-B5, C1-C5)
        private void GenerateSeatGrid()
        {
            pnlSeats.Controls.Clear();
            string[] rows = { "A", "B", "C" };
            int btnWidth = 55, btnHeight = 45;
            int paddingX = 12, paddingY = 20;

            for (int r = 0; r < 3; r++)
            {
                for (int c = 1; c <= 5; c++)
                {
                    string seatName = $"{rows[r]}{c}";
                    Button btnSeat = new Button
                    {
                        Text = seatName,
                        Name = "btn_" + seatName,
                        Size = new Size(btnWidth, btnHeight),
                        Location = new Point(paddingX + (c - 1) * (btnWidth + 8), paddingY + r * (btnHeight + 15)),
                        Tag = seatName,
                        BackColor = Color.White
                    };

                    btnSeat.Click += Seat_Click;
                    pnlSeats.Controls.Add(btnSeat);
                }
            }
        }

        private void Seat_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            string key = GetSeatKey(btn.Text);

            // Nếu ghế đã bán rồi thì không cho chọn
            if (seatStatus.ContainsKey(key) && seatStatus[key] == true)
            {
                MessageBox.Show("Ghế này đã được bán!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Đổi màu chọn / hủy chọn
            if (selectedSeatButtons.Contains(btn))
            {
                selectedSeatButtons.Remove(btn);
                btn.BackColor = Color.White;
            }
            else
            {
                selectedSeatButtons.Add(btn);
                btn.BackColor = Color.Yellow;
            }

            CalculateTotalAmount();
        }

        // Tính giá tiền dựa trên loại ghế
        private void CalculateTotalAmount()
        {
            if (cboFilm.SelectedItem == null) return;

            var movie = movieList.First(m => m.Name == cboFilm.SelectedItem.ToString());
            double total = 0;

            foreach (var btn in selectedSeatButtons)
            {
                string seatName = btn.Text;
                double seatPrice = movie.BasePrice;

                // Quy tắc giá vé:
                // A1, A5, C1, C5 -> Vé vớt (BasePrice)
                // A2, A3, A4, C2, C3, C4 -> Vé thường (BasePrice * 1.2)
                // B2, B3, B4 -> Vé VIP (BasePrice * 1.5)
                if (seatName == "A1" || seatName == "A5" || seatName == "C1" || seatName == "C5")
                {
                    seatPrice *= 1.0;
                }
                else if (seatName == "B2" || seatName == "B3" || seatName == "B4")
                {
                    seatPrice *= 1.5; // Vé VIP
                }
                else
                {
                    seatPrice *= 1.2; // Vé thường
                }

                total += seatPrice;
            }

            txtTotal.Text = total.ToString("N0") + " VNĐ";
        }

        // Bấm nút MUA VÉ
        private void btnBuy_Click(object sender, EventArgs e)
        {
            if (selectedSeatButtons.Count == 0)
            {
                MessageBox.Show("Vui lòng chọn ít nhất 1 ghế!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            foreach (var btn in selectedSeatButtons)
            {
                string key = GetSeatKey(btn.Text);
                seatStatus[key] = true; // Đánh dấu đã bán
                btn.BackColor = Color.Red; // Ghế đã bán đổi sang màu Đỏ
            }

            MessageBox.Show($"Thanh toán thành công {txtTotal.Text}!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            selectedSeatButtons.Clear();
            txtTotal.Clear();
        }

        // Bấm nút XUẤT BÁO CÁO (Thống kê)
        private void btnReport_Click(object sender, EventArgs e)
        {
            rtbReport.Clear();
            rtbReport.AppendText("===== BÁO CÁO DOANH THU RẠP PHIM =====\n\n");

            int totalSeatsPerShow = 15; // Mỗi phòng có 15 ghế
            double grandTotalRevenue = 0;

            foreach (var movie in movieList)
            {
                rtbReport.AppendText($"🎬 PHIM: {movie.Name.ToUpper()}\n");
                double movieRevenue = 0;

                foreach (int room in movie.Rooms)
                {
                    int soldSeats = 0;
                    for (int r = 0; r < 3; r++)
                    {
                        string[] rows = { "A", "B", "C" };
                        for (int c = 1; c <= 5; c++)
                        {
                            string seatName = $"{rows[r]}{c}";
                            string key = $"{movie.Name}_{room}_{seatName}";

                            if (seatStatus.ContainsKey(key) && seatStatus[key] == true)
                            {
                                soldSeats++;

                                double price = movie.BasePrice;
                                if (seatName == "A1" || seatName == "A5" || seatName == "C1" || seatName == "C5") price *= 1.0;
                                else if (seatName == "B2" || seatName == "B3" || seatName == "B4") price *= 1.5;
                                else price *= 1.2;

                                movieRevenue += price;
                            }
                        }
                    }

                    double rate = ((double)soldSeats / totalSeatsPerShow) * 100;
                    rtbReport.AppendText($"  • Phòng {room}: Bán {soldSeats}/{totalSeatsPerShow} vé ({rate:F1}%)\n");
                }

                rtbReport.AppendText($"  👉 Doanh thu: {movieRevenue:N0} VNĐ\n");
                rtbReport.AppendText("-------------------------------------\n");
                grandTotalRevenue += movieRevenue;
            }

            rtbReport.AppendText($"💰 TỔNG DOANH THU RẠP: {grandTotalRevenue:N0} VNĐ\n");
        }

        private string GetSeatKey(string seatName)
        {
            return $"{cboFilm.SelectedItem}_{cboRoom.SelectedItem}_{seatName}";
        }

        private void ResetSeatSelection()
        {
            selectedSeatButtons.Clear();
            txtTotal.Clear();

            if (cboFilm.SelectedItem == null || cboRoom.SelectedItem == null) return;

            foreach (Control ctrl in pnlSeats.Controls)
            {
                if (ctrl is Button btn)
                {
                    string key = GetSeatKey(btn.Text);
                    if (seatStatus.ContainsKey(key) && seatStatus[key] == true)
                    {
                        btn.BackColor = Color.Red; // Ghế đã bán
                    }
                    else
                    {
                        btn.BackColor = Color.White; // Ghế còn trống
                    }
                }
            }
        }
    }
}