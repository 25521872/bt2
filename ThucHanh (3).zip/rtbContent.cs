﻿namespace Lab02
{
    internal class rtbContent
    {
        internal static readonly object Text;
    }
}