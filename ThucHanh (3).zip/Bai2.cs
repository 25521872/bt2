﻿using System;
using System.IO;
using System.Windows.Forms;

namespace THUCHANH
{
    public partial class Bai2 : Form
    {
        public Bai2()
        {
            InitializeComponent();
        }

        // Sự kiện click Nút ĐỌC FILE (button1)
        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            ofd.Title = "Chọn file dữ liệu";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    textBox1.Text = ofd.SafeFileName;

                    using (FileStream fs = new FileStream(ofd.FileName, FileMode.Open, FileAccess.Read))
                    using (StreamReader sr = new StreamReader(fs))
                    {
                        string content = sr.ReadToEnd();
                        richTextBox1.Text = content;

                        // Tính toán các chỉ số
                        int charCount = content.Length;

                        string[] lines = content.Split(new[] { "\r\n", "\r", "\n" }, StringSplitOptions.None);
                        int lineCount = lines.Length;

                        char[] separators = new char[] { ' ', '\r', '\n', '\t' };
                        string[] words = content.Split(separators, StringSplitOptions.RemoveEmptyEntries);
                        int wordCount = words.Length;

                        // Hiển thị ra các TextBox
                        textBox2.Text = lineCount.ToString();
                        textBox3.Text = wordCount.ToString();
                        textBox4.Text = charCount.ToString();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi đọc file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Sự kiện click Nút GHI FILE (button2)
        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            sfd.FileName = "output2.txt";
            sfd.Title = "Lưu kết quả thống kê";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create, FileAccess.Write))
                    using (StreamWriter sw = new StreamWriter(fs))
                    {
                        sw.WriteLine("--- KẾT QUẢ THỐNG KÊ FILE ---");
                        sw.WriteLine("Tên file: " + textBox1.Text);
                        sw.WriteLine("Số dòng: " + textBox2.Text);
                        sw.WriteLine("Số từ: " + textBox3.Text);
                        sw.WriteLine("Số ký tự: " + textBox4.Text);
                        sw.WriteLine("------------------------------");
                        sw.WriteLine("Nội dung file:");
                        sw.Write(richTextBox1.Text);
                    }

                    MessageBox.Show("Đã ghi file kết quả thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi ghi file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}