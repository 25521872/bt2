﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace THUCHANH
{
    public partial class Bai4 : Form
    {
        // Khai báo cấu trúc SinhVien
        [Serializable]
        public class Student
        {
            public string MSSV { get; set; }
            public string Name { get; set; }
            public string Phone { get; set; }
            public float Course1 { get; set; }
            public float Course2 { get; set; }
            public float Course3 { get; set; }
            public float Average { get; set; }

            public Student() { }

            public Student(string mssv, string name, string phone, float c1, float c2, float c3)
            {
                MSSV = mssv;
                Name = name;
                Phone = phone;
                Course1 = c1;
                Course2 = c2;
                Course3 = c3;
                Average = (c1 + c2 + c3) / 3;
            }
        }

        private List<Student> studentListInput = new List<Student>();
        private List<Student> studentListRead = new List<Student>();
        private int currentIndex = -1;

        public Bai4()
        {
            InitializeComponent();
        }

        // 1. Thêm Sinh viên vào danh sách tạm
        private void btnAddStudent_Click(object sender, EventArgs e)
        {
            try
            {
                string mssv = txtMSSV.Text.Trim();
                string name = txtName.Text.Trim();
                string phone = txtPhone.Text.Trim();

                if (string.IsNullOrEmpty(mssv) || string.IsNullOrEmpty(name))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ MSSV và Họ tên!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                float c1 = float.Parse(txtCourse1.Text);
                float c2 = float.Parse(txtCourse2.Text);
                float c3 = float.Parse(txtCourse3.Text);

                Student st = new Student(mssv, name, phone, c1, c2, c3);
                studentListInput.Add(st);

                // Cập nhật lên khung hiển thị
                rtbContent.AppendText($"[Thêm mới] {st.MSSV} - {st.Name} | ĐTB: {st.Average:F2}\n");

                // Clear ô nhập
                ClearInputs();
                MessageBox.Show($"Đã thêm sinh viên {st.Name}!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Điểm nhập vào phải là số thực hợp lệ: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 2. Ghi danh sách Sinh viên xuống file (BinaryWriter)
        private void btnWriteToFile_Click(object sender, EventArgs e)
        {
            if (studentListInput.Count == 0)
            {
                MessageBox.Show("Danh sách sinh viên rỗng!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Binary Files (*.bin)|*.bin|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            sfd.FileName = "input4.bin";

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    using (FileStream fs = new FileStream(sfd.FileName, FileMode.Create))
                    using (BinaryWriter bw = new BinaryWriter(fs))
                    {
                        // Ghi số lượng sinh viên trước
                        bw.Write(studentListInput.Count);

                        foreach (Student st in studentListInput)
                        {
                            bw.Write(st.MSSV);
                            bw.Write(st.Name);
                            bw.Write(st.Phone);
                            bw.Write(st.Course1);
                            bw.Write(st.Course2);
                            bw.Write(st.Course3);
                            bw.Write(st.Average);
                        }
                    }

                    MessageBox.Show("Đã ghi thành công " + studentListInput.Count + " sinh viên vào file!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi ghi file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // 3. Đọc danh sách Sinh viên từ file (BinaryReader)
        private void btnReadFromFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Binary Files (*.bin)|*.bin|Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    studentListRead.Clear();

                    using (FileStream fs = new FileStream(ofd.FileName, FileMode.Open))
                    using (BinaryReader br = new BinaryReader(fs))
                    {
                        int count = br.ReadInt32();

                        for (int i = 0; i < count; i++)
                        {
                            Student st = new Student();
                            st.MSSV = br.ReadString();
                            st.Name = br.ReadString();
                            st.Phone = br.ReadString();
                            st.Course1 = br.ReadSingle();
                            st.Course2 = br.ReadSingle();
                            st.Course3 = br.ReadSingle();
                            st.Average = br.ReadSingle();

                            studentListRead.Add(st);
                        }
                    }

                    if (studentListRead.Count > 0)
                    {
                        currentIndex = 0;
                        DisplayStudent(currentIndex);
                        DisplayAllStudentsToRichTextBox();
                        MessageBox.Show("Đọc file thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi đọc file: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        // Nút Back
        private void btnBack_Click(object sender, EventArgs e)
        {
            if (studentListRead.Count == 0) return;

            if (currentIndex > 0)
            {
                currentIndex--;
                DisplayStudent(currentIndex);
            }
        }

        // Nút Next
        private void btnNext_Click(object sender, EventArgs e)
        {
            if (studentListRead.Count == 0) return;

            if (currentIndex < studentListRead.Count - 1)
            {
                currentIndex++;
                DisplayStudent(currentIndex);
            }
        }

        // Hiển thị thông tin sinh viên tại trang hiện tại
        private void DisplayStudent(int index)
        {
            if (index >= 0 && index < studentListRead.Count)
            {
                Student st = studentListRead[index];
                txtMSSV.Text = st.MSSV;
                txtName.Text = st.Name;
                txtPhone.Text = st.Phone;
                txtCourse1.Text = st.Course1.ToString();
                txtCourse2.Text = st.Course2.ToString();
                txtCourse3.Text = st.Course3.ToString();
                txtAverage.Text = st.Average.ToString("F2");

                lblPage.Text = $"{index + 1} / {studentListRead.Count}";
            }
        }

        private void DisplayAllStudentsToRichTextBox()
        {
            rtbContent.Clear();
            rtbContent.AppendText("=== DANH SÁCH SINH VIÊN ĐÃ ĐỌC TỪ FILE ===\n\n");
            foreach (var st in studentListRead)
            {
                rtbContent.AppendText($"MSSV: {st.MSSV}\n");
                rtbContent.AppendText($"Họ tên: {st.Name}\n");
                rtbContent.AppendText($"SĐT: {st.Phone}\n");
                rtbContent.AppendText($"Môn 1: {st.Course1} | Môn 2: {st.Course2} | Môn 3: {st.Course3}\n");
                rtbContent.AppendText($"ĐTB: {st.Average:F2}\n");
                rtbContent.AppendText("-----------------------------------\n");
            }
        }

        private void ClearInputs()
        {
            txtMSSV.Clear();
            txtName.Clear();
            txtPhone.Clear();
            txtCourse1.Clear();
            txtCourse2.Clear();
            txtCourse3.Clear();
            txtAverage.Clear();
        }
    }
}